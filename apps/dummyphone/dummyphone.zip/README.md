dummyphone-app
==============

An application that encodes and decodes a code called DummyPhone. Comes in 2 versions - PHP web edition and Python program edition
